<!-- before posting an issue, try chatting on https://gitter.im/pattern-lab/node -->
<!-- before posting an issue, please check closed issues: https://github.com/pattern-lab/edition-node-gulp/issues?q=is%3Aissue+is%3Aclosed -->

I am using Pattern Lab Node- Gulp Edition `vX.X.X` on `Windows|Mac|Linux`.

##### Expected Behavior


##### Actual Behavior


##### Steps to Reproduce
